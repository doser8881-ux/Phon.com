const MY_PHONE = "+249900088522"; // 🔴 غيّر هذا الرقم إلى رقمك الحقيقي

document.querySelectorAll(".call-btn").forEach(button => {
    button.addEventListener("click", function() {
        try {
            window.location.href = `tel:${MY_PHONE}`;
        } catch(e) {
            alert(`سيتصل على الرقم: ${MY_PHONE}`);
        }
    });
});